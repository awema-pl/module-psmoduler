<?php

namespace Psmoduler\Repository;
class RepresentativeRepository
{
    public function getData()
    {
       return ['wef'];
    }
}
