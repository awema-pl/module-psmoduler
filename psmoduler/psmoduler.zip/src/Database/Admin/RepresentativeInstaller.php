<?php

namespace Psmoduler\Database\Admin;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DBALException;
use Doctrine\DBAL\Driver\Statement;

class RepresentativeInstaller implements RepresentativeInstallerInterface
{
    /**
     * @var Connection
     */
    private $connection;

    /**
     * @var string
     */
    private $dbPrefix;

    public function __construct(Connection $connection) {
        $this->connection = $connection;
        $this->dbPrefix = _DB_PREFIX_;
    }

    /**
     * Install
     *
     * @return array|null
     * @throws \Doctrine\DBAL\DBALException
     */
    public function install()
    {
        $error = '';
        $this->uninstall();
        $sqlInstallFile = _PS_MODULE_DIR_ .'psmoduler/database/sql/2020_12_11_230000_create_representatives_table.sql';
        $sqlQuery=file_get_contents($sqlInstallFile);
        $sqlQuery = str_replace('PREFIX_', $this->dbPrefix, $sqlQuery);

        if (!empty($sqlQuery)) {
            $statement = $this->connection->executeQuery($sqlQuery);
            if (0 != (int) $statement->errorCode()) {
                $error = [
                    'key' => json_encode($statement->errorInfo()),
                    'parameters' => [],
                    'domain' => 'Modules.Psmoduler.Psmoduler',
                ];
            }
        }
        return $error;
    }

    /**
     * Uninstall
     *
     * @return array|null
     * @throws DBALException
     */
    public function uninstall()
    {
        $error = '';
        $sqlUninstallFile = _PS_MODULE_DIR_ .'psmoduler/database/sql/2020_12_11_230000_drop_representatives_table.sql';
        $sqlQuery=file_get_contents($sqlUninstallFile);
        $sqlQuery = str_replace('PREFIX_', $this->dbPrefix, $sqlQuery);

        if (!empty($sqlQuery)) {
            $statement = $this->connection->executeQuery($sqlQuery);
            if (0 != (int) $statement->errorCode()) {
                $error = [
                    'key' => json_encode($statement->errorInfo()),
                    'parameters' => [],
                    'domain' => 'Modules.Psmoduler.Psmoduler',
                ];
            }
        }

        return $error;
    }
}
