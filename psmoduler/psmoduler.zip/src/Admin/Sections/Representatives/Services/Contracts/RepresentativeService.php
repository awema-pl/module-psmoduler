<?php

namespace Psmoduler\Admin\Sections\Representatives\Services\Contracts;
interface RepresentativeService
{
    /**
     * Generate code
     *
     * @return string
     */
    public function generateCode();
}
