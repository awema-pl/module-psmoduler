<?php

declare(strict_types=1);

namespace Psmoduler\Admin\Sections\Commons\Exceptions;

use Exception;

class PsmodulerException extends Exception
{

}
