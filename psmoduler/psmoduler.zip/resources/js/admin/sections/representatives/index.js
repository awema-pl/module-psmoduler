const $ = window.$;
(() => {
    console.log('Module Psmoduler');
})();